import { CountriesSecond } from "@/components/widgets"
import { KJCSecond } from "@/components/widgets/KJCSecond"

const backgroundScreen =
	"min-h-screen flex flex-col items-center justify-center bg-[url('/images/kjc-events-second-bg.png')] bg-no-repeat bg-cover"

export default function EventsSecond() {
	return (
		<>
			<div className={backgroundScreen}>
				<div className="container-lg flex flex-col gap-2 z-10">
					<KJCSecond />
					<CountriesSecond />
				</div>
			</div>
		</>
	)
}
