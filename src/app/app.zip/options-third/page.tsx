import {
	BannerFooter,
	Contact,
	CountriesThird,
	KJCThird
} from "@/components/widgets"

const backgroundScreen =
	"min-h-screen min-w-screen flex flex-col justify-center gap-10 bg-[url('/images/kjc-events-third-bg.png')] bg-no-repeat bg-cover"

export default function EventsSecond() {
	return (
		<>
			<div className={backgroundScreen}>
				<div className="container-lg">
					<KJCThird />
				</div>

				<div className="bg-gray-500/30 backdrop-blur-2xl backdrop-opacity-10 py-5">
					<div className="container">
						<CountriesThird />
					</div>
				</div>

				<div className="container">
					<BannerFooter />
					<Contact />
				</div>
			</div>
		</>
	)
}
